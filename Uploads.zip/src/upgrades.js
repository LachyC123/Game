// Upgrades System

class UpgradesManager {
    constructor() {
        this.upgrades = [
            {
                id: 'click_power_1',
                name: 'Neural Amplifier',
                icon: '🧠',
                description: 'Enhance your neural pathways for more powerful clicks',
                effect: 'Click power +1',
                baseCost: 10,
                costMultiplier: 1.15,
                currentLevel: 0,
                maxLevel: 100,
                apply: (game) => {
                    game.clickPower += 1;
                }
            },
            {
                id: 'click_power_2',
                name: 'Quantum Processor',
                icon: '⚛️',
                description: 'Quantum computing for exponential click gains',
                effect: 'Click power +5',
                baseCost: 100,
                costMultiplier: 1.2,
                currentLevel: 0,
                maxLevel: 50,
                unlockCondition: (game) => game.stats.totalClicks >= 100,
                apply: (game) => {
                    game.clickPower += 5;
                }
            },
            {
                id: 'click_power_3',
                name: 'Cyber Implant',
                icon: '🔧',
                description: 'Cybernetic enhancement for superhuman clicking',
                effect: 'Click power +25',
                baseCost: 1000,
                costMultiplier: 1.25,
                currentLevel: 0,
                maxLevel: 25,
                unlockCondition: (game) => game.stats.totalClicks >= 500,
                apply: (game) => {
                    game.clickPower += 25;
                }
            },
            {
                id: 'global_mult_1',
                name: 'Energy Catalyst',
                icon: '💎',
                description: 'Catalyze all energy production',
                effect: 'Global multiplier +10%',
                baseCost: 500,
                costMultiplier: 1.5,
                currentLevel: 0,
                maxLevel: 20,
                unlockCondition: (game) => game.energy >= 200,
                apply: (game) => {
                    game.globalMultiplier += 0.1;
                }
            },
            {
                id: 'global_mult_2',
                name: 'Fusion Reactor',
                icon: '⚡',
                description: 'Nuclear fusion for massive power gains',
                effect: 'Global multiplier +25%',
                baseCost: 5000,
                costMultiplier: 1.75,
                currentLevel: 0,
                maxLevel: 10,
                unlockCondition: (game) => game.energy >= 2000,
                apply: (game) => {
                    game.globalMultiplier += 0.25;
                }
            },
            {
                id: 'combo_duration',
                name: 'Time Dilation',
                icon: '⏰',
                description: 'Slow down time to maintain combos longer',
                effect: 'Combo window +1s',
                baseCost: 250,
                costMultiplier: 1.4,
                currentLevel: 0,
                maxLevel: 15,
                unlockCondition: (game) => game.stats.highestCombo >= 5,
                apply: (game) => {
                    game.comboWindow += 1000;
                }
            },
            {
                id: 'combo_power',
                name: 'Synergy Matrix',
                icon: '🎯',
                description: 'Increase the power of combo multipliers',
                effect: 'Combo bonus +5%',
                baseCost: 750,
                costMultiplier: 1.6,
                currentLevel: 0,
                maxLevel: 20,
                unlockCondition: (game) => game.stats.highestCombo >= 10,
                apply: (game) => {
                    game.comboBonus += 0.05;
                }
            },
            {
                id: 'auto_click',
                name: 'Auto-Clicker Module',
                icon: '🤖',
                description: 'Automated clicking system',
                effect: '1 auto-click per second',
                baseCost: 2000,
                costMultiplier: 2,
                currentLevel: 0,
                maxLevel: 10,
                unlockCondition: (game) => game.energy >= 1000,
                apply: (game) => {
                    game.autoClickersPerSecond += 1;
                }
            },
            {
                id: 'crit_chance',
                name: 'Lucky Strike',
                icon: '🍀',
                description: 'Chance to deal critical clicks',
                effect: '+5% crit chance',
                baseCost: 1500,
                costMultiplier: 1.8,
                currentLevel: 0,
                maxLevel: 10,
                unlockCondition: (game) => game.stats.totalClicks >= 1000,
                apply: (game) => {
                    game.critChance += 0.05;
                }
            },
            {
                id: 'crit_power',
                name: 'Overcharge',
                icon: '💥',
                description: 'Increase critical click damage',
                effect: 'Crits deal +50% damage',
                baseCost: 3000,
                costMultiplier: 2.5,
                currentLevel: 0,
                maxLevel: 5,
                unlockCondition: (game) => game.critChance >= 0.05,
                apply: (game) => {
                    game.critMultiplier += 0.5;
                }
            }
        ];
    }

    getUpgrade(id) {
        return this.upgrades.find(u => u.id === id);
    }

    getCost(upgrade) {
        return Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, upgrade.currentLevel));
    }

    canAfford(upgrade, energy) {
        return energy >= this.getCost(upgrade);
    }

    isUnlocked(upgrade, game) {
        if (!upgrade.unlockCondition) return true;
        return upgrade.unlockCondition(game);
    }

    isMaxed(upgrade) {
        return upgrade.currentLevel >= upgrade.maxLevel;
    }

    purchase(upgrade, game) {
        if (this.isMaxed(upgrade)) return false;
        if (!this.canAfford(upgrade, game.energy)) return false;
        if (!this.isUnlocked(upgrade, game)) return false;

        const cost = this.getCost(upgrade);
        game.energy -= cost;
        upgrade.currentLevel++;
        upgrade.apply(game);

        // Create burst effect
        const upgradeCard = document.querySelector(`[data-upgrade-id="${upgrade.id}"]`);
        if (upgradeCard) {
            const rect = upgradeCard.getBoundingClientRect();
            particleSystem.createBurst(
                rect.left + rect.width / 2,
                rect.top + rect.height / 2,
                15,
                '#00ffff'
            );
        }

        notifications.success(
            '⚡ Upgrade Purchased!',
            `${upgrade.name} Level ${upgrade.currentLevel}`
        );

        return true;
    }

    reset() {
        this.upgrades.forEach(upgrade => {
            upgrade.currentLevel = 0;
        });
    }

    getSaveData() {
        const data = {};
        this.upgrades.forEach(upgrade => {
            data[upgrade.id] = upgrade.currentLevel;
        });
        return data;
    }

    loadSaveData(data) {
        if (!data) return;
        Object.keys(data).forEach(id => {
            const upgrade = this.getUpgrade(id);
            if (upgrade) {
                upgrade.currentLevel = data[id];
            }
        });
    }
}

const upgradesManager = new UpgradesManager();
