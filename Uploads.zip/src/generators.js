// Generators (Passive Income) System

class GeneratorsManager {
    constructor() {
        this.generators = [
            {
                id: 'gen_1',
                name: 'Nano Bot',
                icon: '🤖',
                description: 'Tiny robots that generate energy automatically',
                baseProduction: 0.1,
                baseCost: 15,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 0
            },
            {
                id: 'gen_2',
                name: 'Solar Panel',
                icon: '☀️',
                description: 'Harness the power of stars',
                baseProduction: 1,
                baseCost: 100,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 50
            },
            {
                id: 'gen_3',
                name: 'Quantum Core',
                icon: '⚛️',
                description: 'Quantum entanglement for infinite energy',
                baseProduction: 8,
                baseCost: 1100,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 500
            },
            {
                id: 'gen_4',
                name: 'Fusion Plant',
                icon: '⚡',
                description: 'Nuclear fusion power station',
                baseProduction: 47,
                baseCost: 12000,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 5000
            },
            {
                id: 'gen_5',
                name: 'Antimatter Reactor',
                icon: '💫',
                description: 'Harness the power of antimatter',
                baseProduction: 260,
                baseCost: 130000,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 50000
            },
            {
                id: 'gen_6',
                name: 'Dark Energy Collector',
                icon: '🌌',
                description: 'Tap into the mysterious dark energy of the universe',
                baseProduction: 1400,
                baseCost: 1400000,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 500000
            },
            {
                id: 'gen_7',
                name: 'Time Singularity',
                icon: '⏳',
                description: 'Generate energy from time itself',
                baseProduction: 7800,
                baseCost: 20000000,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 5000000
            },
            {
                id: 'gen_8',
                name: 'Reality Engine',
                icon: '🌠',
                description: 'Rewrite reality to generate infinite power',
                baseProduction: 44000,
                baseCost: 330000000,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 50000000
            },
            {
                id: 'gen_9',
                name: 'Dimension Gateway',
                icon: '🔮',
                description: 'Draw energy from parallel dimensions',
                baseProduction: 260000,
                baseCost: 5100000000,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 500000000
            },
            {
                id: 'gen_10',
                name: 'Universal Nexus',
                icon: '🌟',
                description: 'The ultimate energy source from the fabric of existence',
                baseProduction: 1600000,
                baseCost: 75000000000,
                costMultiplier: 1.15,
                count: 0,
                unlockCost: 5000000000
            }
        ];
    }

    getGenerator(id) {
        return this.generators.find(g => g.id === id);
    }

    getCost(generator) {
        return Math.floor(generator.baseCost * Math.pow(generator.costMultiplier, generator.count));
    }

    getProduction(generator, game) {
        if (generator.count === 0) return 0;
        
        let production = generator.baseProduction * generator.count;
        
        // Apply generator-specific multipliers from achievements
        // Apply global multiplier
        production *= game.globalMultiplier;
        
        // Apply prestige multiplier
        production *= game.prestigeMultiplier;
        
        return production;
    }

    getTotalProduction(game) {
        return this.generators.reduce((total, gen) => {
            return total + this.getProduction(gen, game);
        }, 0);
    }

    canAfford(generator, energy) {
        return energy >= this.getCost(generator);
    }

    isUnlocked(generator, totalEnergy) {
        return totalEnergy >= generator.unlockCost;
    }

    purchase(generator, game) {
        if (!this.canAfford(generator, game.energy)) return false;
        if (!this.isUnlocked(generator, game.stats.totalEnergy)) return false;

        const cost = this.getCost(generator);
        game.energy -= cost;
        generator.count++;

        // Create burst effect
        const genCard = document.querySelector(`[data-generator-id="${generator.id}"]`);
        if (genCard) {
            const rect = genCard.getBoundingClientRect();
            particleSystem.createBurst(
                rect.left + rect.width / 2,
                rect.top + rect.height / 2,
                15,
                '#0080ff'
            );
        }

        notifications.success(
            '🔋 Generator Purchased!',
            `${generator.name} x${generator.count}`
        );

        return true;
    }

    reset() {
        this.generators.forEach(gen => {
            gen.count = 0;
        });
    }

    getSaveData() {
        const data = {};
        this.generators.forEach(gen => {
            data[gen.id] = gen.count;
        });
        return data;
    }

    loadSaveData(data) {
        if (!data) return;
        Object.keys(data).forEach(id => {
            const gen = this.getGenerator(id);
            if (gen) {
                gen.count = data[id];
            }
        });
    }
}

const generatorsManager = new GeneratorsManager();
