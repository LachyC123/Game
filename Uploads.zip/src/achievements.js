// Achievements System

class AchievementsManager {
    constructor() {
        this.achievements = [
            // Click-based achievements
            {
                id: 'first_click',
                name: 'First Contact',
                icon: '👆',
                description: 'Make your first click',
                tier: 'bronze',
                reward: 'Click power +1',
                condition: (game) => game.stats.totalClicks >= 1,
                unlocked: false,
                apply: (game) => { game.clickPower += 1; }
            },
            {
                id: 'clicks_100',
                name: 'Clicker Novice',
                icon: '🎖️',
                description: 'Make 100 clicks',
                tier: 'bronze',
                reward: 'Global mult +5%',
                condition: (game) => game.stats.totalClicks >= 100,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.05; }
            },
            {
                id: 'clicks_1000',
                name: 'Clicker Adept',
                icon: '🏅',
                description: 'Make 1,000 clicks',
                tier: 'silver',
                reward: 'Global mult +10%',
                condition: (game) => game.stats.totalClicks >= 1000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.1; }
            },
            {
                id: 'clicks_10000',
                name: 'Clicker Master',
                icon: '🏆',
                description: 'Make 10,000 clicks',
                tier: 'gold',
                reward: 'Global mult +20%',
                condition: (game) => game.stats.totalClicks >= 10000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.2; }
            },
            {
                id: 'clicks_100000',
                name: 'Click God',
                icon: '👑',
                description: 'Make 100,000 clicks',
                tier: 'platinum',
                reward: 'Global mult +50%',
                condition: (game) => game.stats.totalClicks >= 100000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.5; }
            },
            
            // Energy-based achievements
            {
                id: 'energy_100',
                name: 'Energy Collector',
                icon: '⚡',
                description: 'Collect 100 total energy',
                tier: 'bronze',
                reward: 'Click power +2',
                condition: (game) => game.stats.totalEnergy >= 100,
                unlocked: false,
                apply: (game) => { game.clickPower += 2; }
            },
            {
                id: 'energy_10000',
                name: 'Power Plant',
                icon: '🏭',
                description: 'Collect 10,000 total energy',
                tier: 'silver',
                reward: 'Global mult +15%',
                condition: (game) => game.stats.totalEnergy >= 10000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.15; }
            },
            {
                id: 'energy_1000000',
                name: 'Energy Tycoon',
                icon: '💰',
                description: 'Collect 1,000,000 total energy',
                tier: 'gold',
                reward: 'Global mult +30%',
                condition: (game) => game.stats.totalEnergy >= 1000000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.3; }
            },
            {
                id: 'energy_billion',
                name: 'Energy Magnate',
                icon: '🔱',
                description: 'Collect 1 billion total energy',
                tier: 'platinum',
                reward: 'Global mult +100%',
                condition: (game) => game.stats.totalEnergy >= 1000000000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 1; }
            },
            
            // Combo-based achievements
            {
                id: 'combo_10',
                name: 'Combo Starter',
                icon: '🌟',
                description: 'Reach a 10x combo',
                tier: 'bronze',
                reward: 'Combo bonus +10%',
                condition: (game) => game.stats.highestCombo >= 10,
                unlocked: false,
                apply: (game) => { game.comboBonus += 0.1; }
            },
            {
                id: 'combo_50',
                name: 'Combo Expert',
                icon: '🔥',
                description: 'Reach a 50x combo',
                tier: 'silver',
                reward: 'Combo bonus +25%',
                condition: (game) => game.stats.highestCombo >= 50,
                unlocked: false,
                apply: (game) => { game.comboBonus += 0.25; }
            },
            {
                id: 'combo_100',
                name: 'Combo Master',
                icon: '✨',
                description: 'Reach a 100x combo',
                tier: 'gold',
                reward: 'Combo bonus +50%',
                condition: (game) => game.stats.highestCombo >= 100,
                unlocked: false,
                apply: (game) => { game.comboBonus += 0.5; }
            },
            
            // Generator-based achievements
            {
                id: 'first_generator',
                name: 'Automation Begins',
                icon: '🤖',
                description: 'Purchase your first generator',
                tier: 'bronze',
                reward: 'Generator output +10%',
                condition: (game) => {
                    return generatorsManager.generators.some(g => g.count > 0);
                },
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.1; }
            },
            {
                id: 'ten_generators',
                name: 'Factory Owner',
                icon: '🏭',
                description: 'Own 10 total generators',
                tier: 'silver',
                reward: 'Generator output +25%',
                condition: (game) => {
                    const total = generatorsManager.generators.reduce((sum, g) => sum + g.count, 0);
                    return total >= 10;
                },
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.25; }
            },
            {
                id: 'hundred_generators',
                name: 'Industrial Complex',
                icon: '🏗️',
                description: 'Own 100 total generators',
                tier: 'gold',
                reward: 'Generator output +50%',
                condition: (game) => {
                    const total = generatorsManager.generators.reduce((sum, g) => sum + g.count, 0);
                    return total >= 100;
                },
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.5; }
            },
            
            // Prestige-based achievements
            {
                id: 'first_prestige',
                name: 'Ascension',
                icon: '🌟',
                description: 'Prestige for the first time',
                tier: 'gold',
                reward: 'Prestige gain +10%',
                condition: (game) => game.prestigeCount >= 1,
                unlocked: false,
                apply: (game) => { game.prestigePointsBonus += 0.1; }
            },
            {
                id: 'prestige_10',
                name: 'Eternal Cycle',
                icon: '♻️',
                description: 'Prestige 10 times',
                tier: 'platinum',
                reward: 'Prestige gain +25%',
                condition: (game) => game.prestigeCount >= 10,
                unlocked: false,
                apply: (game) => { game.prestigePointsBonus += 0.25; }
            },
            {
                id: 'prestige_50',
                name: 'Transcendent',
                icon: '🔮',
                description: 'Prestige 50 times',
                tier: 'diamond',
                reward: 'Prestige gain +50%',
                condition: (game) => game.prestigeCount >= 50,
                unlocked: false,
                apply: (game) => { game.prestigePointsBonus += 0.5; }
            },
            
            // Time-based achievements
            {
                id: 'play_1hour',
                name: 'Dedicated',
                icon: '⏰',
                description: 'Play for 1 hour',
                tier: 'bronze',
                reward: 'Global mult +10%',
                condition: (game) => game.stats.playTime >= 3600,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.1; }
            },
            {
                id: 'play_10hours',
                name: 'Committed',
                icon: '⌛',
                description: 'Play for 10 hours',
                tier: 'silver',
                reward: 'Global mult +25%',
                condition: (game) => game.stats.playTime >= 36000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 0.25; }
            },
            {
                id: 'play_100hours',
                name: 'Obsessed',
                icon: '🔥',
                description: 'Play for 100 hours',
                tier: 'gold',
                reward: 'Global mult +100%',
                condition: (game) => game.stats.playTime >= 360000,
                unlocked: false,
                apply: (game) => { game.globalMultiplier += 1; }
            },
            
            // Special achievements
            {
                id: 'crit_master',
                name: 'Critical Thinker',
                icon: '💥',
                description: 'Land 100 critical clicks',
                tier: 'silver',
                reward: 'Crit chance +5%',
                condition: (game) => game.stats.criticalClicks >= 100,
                unlocked: false,
                apply: (game) => { game.critChance += 0.05; }
            },
            {
                id: 'powerup_user',
                name: 'Power User',
                icon: '⚡',
                description: 'Use 50 power-ups',
                tier: 'silver',
                reward: 'Power-up duration +10%',
                condition: (game) => game.stats.powerupsUsed >= 50,
                unlocked: false,
                apply: (game) => { game.powerupDurationBonus += 0.1; }
            },
            {
                id: 'event_hunter',
                name: 'Event Hunter',
                icon: '🎁',
                description: 'Complete 25 special events',
                tier: 'gold',
                reward: 'Event spawn rate +25%',
                condition: (game) => game.stats.eventsCompleted >= 25,
                unlocked: false,
                apply: (game) => { game.eventSpawnBonus += 0.25; }
            }
        ];
    }

    check(game) {
        let newUnlocks = [];
        
        this.achievements.forEach(achievement => {
            if (!achievement.unlocked && achievement.condition(game)) {
                achievement.unlocked = true;
                achievement.apply(game);
                newUnlocks.push(achievement);
                
                // Show notification and celebration
                notifications.success(
                    `🏆 Achievement Unlocked!`,
                    `${achievement.name} - ${achievement.reward}`,
                    4000
                );
                
                // Create celebration effect
                const achievementCard = document.querySelector(`[data-achievement-id="${achievement.id}"]`);
                if (achievementCard) {
                    particleSystem.createCelebration(achievementCard);
                }
            }
        });
        
        return newUnlocks;
    }

    getUnlockedCount() {
        return this.achievements.filter(a => a.unlocked).length;
    }

    getTotalCount() {
        return this.achievements.length;
    }

    getProgress(achievement, game) {
        // This is a simplified version - you'd need to track individual progress
        return achievement.unlocked ? 100 : 0;
    }

    reset(keepPrestige = false) {
        this.achievements.forEach(achievement => {
            // Keep prestige achievements if specified
            if (keepPrestige && achievement.id.startsWith('prestige_')) {
                return;
            }
            achievement.unlocked = false;
        });
    }

    getSaveData() {
        const data = {};
        this.achievements.forEach(achievement => {
            data[achievement.id] = achievement.unlocked;
        });
        return data;
    }

    loadSaveData(data) {
        if (!data) return;
        Object.keys(data).forEach(id => {
            const achievement = this.achievements.find(a => a.id === id);
            if (achievement) {
                achievement.unlocked = data[id];
            }
        });
    }
}

const achievementsManager = new AchievementsManager();
