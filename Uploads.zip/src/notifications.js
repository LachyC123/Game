// Notification System

class NotificationSystem {
    constructor() {
        this.container = document.getElementById('notification-container');
        this.queue = [];
        this.isShowing = false;
    }

    show(title, message, type = 'info', duration = 3000) {
        this.queue.push({ title, message, type, duration });
        if (!this.isShowing) {
            this.processQueue();
        }
    }

    processQueue() {
        if (this.queue.length === 0) {
            this.isShowing = false;
            return;
        }

        this.isShowing = true;
        const { title, message, type, duration } = this.queue.shift();

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-title">${title}</div>
            <div class="notification-message">${message}</div>
        `;

        this.container.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'notificationSlide 0.3s ease reverse';
            setTimeout(() => {
                notification.remove();
                this.processQueue();
            }, 300);
        }, duration);
    }

    success(title, message, duration) {
        this.show(title, message, 'success', duration);
    }

    warning(title, message, duration) {
        this.show(title, message, 'warning', duration);
    }

    error(title, message, duration) {
        this.show(title, message, 'error', duration);
    }

    info(title, message, duration) {
        this.show(title, message, 'info', duration);
    }
}

const notifications = new NotificationSystem();
