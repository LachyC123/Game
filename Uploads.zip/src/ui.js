// UI System

function updateUI(game) {
    // Update energy display
    document.getElementById('energy-amount').textContent = game.formatNumber(game.energy);
    
    // Update energy per second
    const energyPerSec = generatorsManager.getTotalProduction(game);
    document.getElementById('energy-per-sec').textContent = game.formatNumber(energyPerSec);
    
    // Update level
    document.getElementById('player-level').textContent = game.level;
    
    // Update prestige count
    document.getElementById('prestige-count').textContent = game.prestigeCount;
    
    // Update multipliers
    document.getElementById('click-power').textContent = game.formatNumber(game.clickPower * game.clickPowerMultiplier);
    document.getElementById('global-mult').textContent = game.globalMultiplier.toFixed(2);
    
    if (game.prestigeMultiplier > 1) {
        document.getElementById('prestige-mult-display').style.display = 'flex';
        document.getElementById('prestige-mult').textContent = game.prestigeMultiplier.toFixed(2);
    }
    
    // Update combo
    if (game.comboCount > 1) {
        document.getElementById('combo-counter').style.display = 'block';
        document.getElementById('combo-value').textContent = game.comboCount;
    } else {
        document.getElementById('combo-counter').style.display = 'none';
    }
    
    // Update statistics
    document.getElementById('total-clicks').textContent = game.formatNumber(game.stats.totalClicks);
    document.getElementById('total-energy').textContent = game.formatNumber(game.stats.totalEnergy);
    document.getElementById('play-time').textContent = game.formatTime(game.stats.playTime);
    document.getElementById('highest-combo').textContent = game.stats.highestCombo;
    document.getElementById('unlocked-achievements').textContent = achievementsManager.getUnlockedCount();
    document.getElementById('total-achievements').textContent = achievementsManager.getTotalCount();
    
    // Update level progress
    const levelProgress = (game.experience / game.experienceToNextLevel) * 100;
    document.getElementById('level-progress').style.width = levelProgress + '%';
    document.getElementById('level-progress-text').textContent = Math.floor(levelProgress) + '%';
}

function renderUpgrades() {
    const grid = document.getElementById('upgrades-grid');
    grid.innerHTML = '';
    
    upgradesManager.upgrades.forEach(upgrade => {
        const isUnlocked = upgradesManager.isUnlocked(upgrade, game);
        const isMaxed = upgradesManager.isMaxed(upgrade);
        const cost = upgradesManager.getCost(upgrade);
        const canAfford = upgradesManager.canAfford(upgrade, game.energy);
        
        if (!isUnlocked) return; // Don't show locked upgrades
        
        const card = document.createElement('div');
        card.className = 'upgrade-card';
        card.dataset.upgradeId = upgrade.id;
        
        if (isMaxed) card.classList.add('maxed');
        
        card.innerHTML = `
            <div class=\"upgrade-header\">
                <span class=\"upgrade-icon\">${upgrade.icon}</span>
                <span class=\"upgrade-level\">Lv. ${upgrade.currentLevel}</span>
            </div>
            <div class=\"upgrade-name\">${upgrade.name}</div>
            <div class=\"upgrade-description\">${upgrade.description}</div>
            <div class=\"upgrade-effect\">${upgrade.effect}</div>
            <div class=\"upgrade-cost\">
                <span class=\"cost-label\">Cost:</span>
                <span class=\"cost-value ${canAfford ? 'affordable' : 'expensive'}\">${game.formatNumber(cost)}</span>
            </div>
        `;
        
        if (!isMaxed) {
            card.addEventListener('click', () => {
                if (upgradesManager.purchase(upgrade, game)) {
                    renderUpgrades();
                }
            });
        }
        
        grid.appendChild(card);
    });
}

function renderGenerators() {
    const list = document.getElementById('generators-list');
    list.innerHTML = '';
    
    generatorsManager.generators.forEach(generator => {
        const isUnlocked = generatorsManager.isUnlocked(generator, game.stats.totalEnergy);
        const cost = generatorsManager.getCost(generator);
        const canAfford = generatorsManager.canAfford(generator, game.energy);
        const production = generatorsManager.getProduction(generator, game);
        
        if (!isUnlocked && generator.unlockCost > 0) {
            // Show locked generator with requirements
            const card = document.createElement('div');
            card.className = 'generator-card locked';
            card.innerHTML = `
                <div class=\"generator-header\">
                    <span class=\"generator-icon\">\ud83d\udd12</span>
                    <div class=\"generator-info\">
                        <div class=\"generator-name\">???</div>
                        <div class=\"generator-production\">Unlock at ${game.formatNumber(generator.unlockCost)} total energy</div>
                    </div>
                </div>
            `;
            list.appendChild(card);
            return;
        }
        
        const card = document.createElement('div');
        card.className = 'generator-card';
        card.dataset.generatorId = generator.id;
        
        card.innerHTML = `
            <div class=\"generator-header\">
                <span class=\"generator-icon\">${generator.icon}</span>
                <div class=\"generator-info\">
                    <div class=\"generator-name\">${generator.name}</div>
                    <div class=\"generator-count\">Owned: <span class=\"generator-count-value\">${generator.count}</span></div>
                </div>
            </div>
            <div class=\"generator-production\">${game.formatNumber(production)}/sec</div>
            <div class=\"generator-footer\">
                <span class=\"generator-cost ${canAfford ? 'affordable' : 'expensive'}\">${game.formatNumber(cost)}</span>
            </div>
        `;
        
        card.addEventListener('click', () => {
            if (generatorsManager.purchase(generator, game)) {
                renderGenerators();
            }
        });
        
        list.appendChild(card);
    });
}

function renderPowerups() {
    const grid = document.getElementById('powerups-grid');
    grid.innerHTML = '';
    
    powerupsManager.powerups.forEach(powerup => {
        const cost = powerupsManager.getCost(powerup, game);
        const canUse = powerupsManager.canUse(powerup, game);
        
        const card = document.createElement('div');
        card.className = 'powerup-card';
        card.dataset.powerupId = powerup.id;
        
        if (powerup.active) card.classList.add('active');
        if (powerup.cooldownRemaining > 0) card.classList.add('cooldown');
        
        let statusHtml = '';
        if (powerup.cooldownRemaining > 0) {
            statusHtml = `<div class=\"powerup-cooldown\">${Math.ceil(powerup.cooldownRemaining)}s</div>`;
        }
        
        card.innerHTML = `
            ${statusHtml}
            <div class=\"powerup-icon\">${powerup.icon}</div>
            <div class=\"powerup-name\">${powerup.name}</div>
            <div class=\"powerup-description\">${powerup.description}</div>
            <div class=\"powerup-duration\">Duration: ${powerup.duration}s</div>
            <div class=\"powerup-cost\">${game.formatNumber(cost)} Energy</div>
        `;
        
        if (canUse) {
            card.addEventListener('click', () => {
                if (powerupsManager.activate(powerup, game)) {
                    renderPowerups();
                }
            });
        }
        
        grid.appendChild(card);
    });
    
    // Update active power-ups display
    renderActivePowerups();
}

function renderActivePowerups() {
    const container = document.getElementById('active-powerups');
    container.innerHTML = '';
    
    const activePowerups = powerupsManager.getActivePowerups();
    
    activePowerups.forEach(powerup => {
        const item = document.createElement('div');
        item.className = 'powerup-active-item';
        
        const progress = (powerup.remaining / powerupsManager.getDuration(powerup, game)) * 100;
        
        item.innerHTML = `
            <div class=\"powerup-active-header\">
                <span class=\"powerup-active-name\">${powerup.icon} ${powerup.name}</span>
                <span class=\"powerup-active-timer\">${Math.ceil(powerup.remaining)}s</span>
            </div>
            <div class=\"powerup-progress\">
                <div class=\"powerup-progress-fill\" style=\"width: ${progress}%\"></div>
            </div>
        `;
        
        container.appendChild(item);
    });
}

function renderAchievements(filter = 'all') {
    const grid = document.getElementById('achievements-grid');
    grid.innerHTML = '';
    
    let achievements = achievementsManager.achievements;
    
    if (filter === 'unlocked') {
        achievements = achievements.filter(a => a.unlocked);
    } else if (filter === 'locked') {
        achievements = achievements.filter(a => !a.unlocked);
    }
    
    achievements.forEach(achievement => {
        const card = document.createElement('div');
        card.className = 'achievement-card';
        card.dataset.achievementId = achievement.id;
        
        if (achievement.unlocked) {
            card.classList.add('unlocked');
        } else {
            card.classList.add('locked');
        }
        
        card.innerHTML = `
            <div class=\"achievement-tier ${achievement.tier}\">${achievement.tier.toUpperCase()}</div>
            <div class=\"achievement-icon\">${achievement.icon}</div>
            <div class=\"achievement-name\">${achievement.name}</div>
            <div class=\"achievement-description\">${achievement.description}</div>
            <div class=\"achievement-reward\">\u2728 ${achievement.reward}</div>
        `;
        
        grid.appendChild(card);
    });
}

function renderPrestige() {
    // Update prestige stats
    document.getElementById('prestige-current-energy').textContent = game.formatNumber(game.stats.totalEnergy);
    document.getElementById('prestige-points-gain').textContent = prestigeManager.getPrestigeGain(game);
    document.getElementById('prestige-points-total').textContent = game.prestigePoints;
    
    const bonus = (game.prestigeMultiplier - 1) * 100;
    document.getElementById('prestige-bonus-display').textContent = '+' + bonus.toFixed(0) + '%';
    
    // Update prestige button
    const prestigeBtn = document.getElementById('prestige-btn');
    const canPrestige = prestigeManager.canPrestige(game);
    prestigeBtn.disabled = !canPrestige;
    
    // Render prestige upgrades
    const grid = document.getElementById('prestige-upgrades-grid');
    grid.innerHTML = '';
    
    prestigeManager.prestigeUpgrades.forEach(upgrade => {
        const cost = prestigeManager.getCost(upgrade);
        const canAfford = prestigeManager.canAfford(upgrade, game.prestigePoints);
        const isMaxed = prestigeManager.isMaxed(upgrade);
        
        const card = document.createElement('div');
        card.className = 'prestige-upgrade-card upgrade-card';
        card.dataset.prestigeUpgradeId = upgrade.id;
        
        if (isMaxed) card.classList.add('maxed');
        
        card.innerHTML = `
            <div class=\"upgrade-header\">
                <span class=\"upgrade-icon\">${upgrade.icon}</span>
                <span class=\"upgrade-level\">Lv. ${upgrade.currentLevel}</span>
            </div>
            <div class=\"upgrade-name\">${upgrade.name}</div>
            <div class=\"upgrade-description\">${upgrade.description}</div>
            <div class=\"upgrade-effect\">${upgrade.effect}</div>
            <div class=\"upgrade-cost\">
                <span class=\"cost-label\">Cost:</span>
                <span class=\"cost-value prestige-points ${canAfford ? 'affordable' : 'expensive'}\">${cost} PP</span>
            </div>
        `;
        
        if (!isMaxed) {
            card.addEventListener('click', () => {
                if (prestigeManager.purchase(upgrade, game)) {
                    renderPrestige();
                }
            });
        }
        
        grid.appendChild(card);
    });
}

function renderMilestones() {
    const list = document.getElementById('milestones-list');
    list.innerHTML = '';
    
    milestonesManager.milestones.forEach(milestone => {
        const progress = milestonesManager.getProgress(milestone, game);
        
        const card = document.createElement('div');
        card.className = 'milestone-item';
        card.dataset.milestoneId = milestone.id;
        
        if (milestone.unlocked) {
            card.classList.add('unlocked');
        }
        
        card.innerHTML = `
            <div class=\"milestone-header\">
                <span class=\"milestone-name\">${milestone.icon} ${milestone.name}</span>
                <span class=\"milestone-reward\">${milestone.reward}</span>
            </div>
            <div class=\"milestone-progress-bar\">
                <div class=\"milestone-progress-fill\" style=\"width: ${progress}%\"></div>
            </div>
            <div class=\"milestone-progress-text\">${game.formatNumber(progress)}%</div>
        `;
        
        list.appendChild(card);
    });
}

function renderEvent() {
    const eventContainer = document.getElementById('special-event');
    const event = eventsManager.currentEvent;
    
    if (event) {
        eventContainer.style.display = 'block';
        document.getElementById('event-title').textContent = event.title;
        document.getElementById('event-description').textContent = event.description;
        
        const timeLeft = Math.ceil(eventsManager.eventTimer / 1000);
        document.getElementById('event-timer').textContent = `${timeLeft}s remaining`;
    } else {
        eventContainer.style.display = 'none';
    }
}

function initializeUI() {
    // Render all tabs
    renderUpgrades();
    renderGenerators();
    renderPowerups();
    renderAchievements();
    renderPrestige();
    renderMilestones();
    renderEvent();
    
    // Tab navigation
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;
            
            // Update active tab button
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Update active tab pane
            document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
            document.getElementById(tab + '-tab').classList.add('active');
            
            // Re-render content
            switch(tab) {
                case 'upgrades':
                    renderUpgrades();
                    break;
                case 'generators':
                    renderGenerators();
                    break;
                case 'powerups':
                    renderPowerups();
                    break;
                case 'achievements':
                    renderAchievements();
                    break;
                case 'prestige':
                    renderPrestige();
                    break;
            }
        });
    });
    
    // Achievement filters
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.dataset.filter;
            
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            renderAchievements(filter);
        });
    });
    
    // Main click button
    document.getElementById('main-click-btn').addEventListener('click', (e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX;
        const y = e.clientY;
        
        game.click(x, y);
    });
    
    // Prestige button
    document.getElementById('prestige-btn').addEventListener('click', () => {
        if (prestigeManager.performPrestige(game)) {
            // Refresh all displays
            renderUpgrades();
            renderGenerators();
            renderPowerups();
            renderAchievements();
            renderPrestige();
            renderMilestones();
        }
    });
    
    // Event claim button
    document.getElementById('event-claim-btn').addEventListener('click', () => {
        eventsManager.claimEvent();
        renderEvent();
    });
    
    // Settings buttons
    document.getElementById('save-btn').addEventListener('click', () => {
        game.saveGame();
        notifications.success('Saved!', 'Game saved successfully');
    });
    
    document.getElementById('load-btn').addEventListener('click', () => {
        location.reload();
    });
    
    document.getElementById('export-btn').addEventListener('click', () => {
        game.exportSave();
    });
    
    document.getElementById('import-btn').addEventListener('click', () => {
        document.getElementById('import-modal').style.display = 'flex';
    });
    
    document.getElementById('import-confirm-btn').addEventListener('click', () => {
        const data = document.getElementById('import-textarea').value.trim();
        if (data) {
            game.importSave(data);
        }
    });
    
    document.getElementById('import-cancel-btn').addEventListener('click', () => {
        document.getElementById('import-modal').style.display = 'none';
        document.getElementById('import-textarea').value = '';
    });
    
    document.getElementById('reset-btn').addEventListener('click', () => {
        game.hardReset();
    });
    
    // Update UI periodically
    setInterval(() => {
        renderEvent();
        renderActivePowerups();
        
        // Update visible tab content
        const activeTab = document.querySelector('.tab-btn.active').dataset.tab;
        switch(activeTab) {
            case 'upgrades':
                renderUpgrades();
                break;
            case 'generators':
                renderGenerators();
                break;
            case 'powerups':
                renderPowerups();
                break;
            case 'prestige':
                renderPrestige();
                break;
        }
    }, 1000);
}
