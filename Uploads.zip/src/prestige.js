// Prestige System

class PrestigeManager {
    constructor() {
        this.prestigeUpgrades = [
            {
                id: 'prestige_mult_1',
                name: 'Nexus Conduit',
                icon: '🌟',
                description: 'Increase prestige multiplier effectiveness',
                effect: '+10% prestige bonus per level',
                baseCost: 1,
                costMultiplier: 2,
                currentLevel: 0,
                maxLevel: 20,
                apply: (game) => {
                    game.prestigeBonus += 0.1;
                }
            },
            {
                id: 'prestige_gain_1',
                name: 'Ascension Catalyst',
                icon: '⭐',
                description: 'Gain more prestige points per ascension',
                effect: '+25% prestige points gained',
                baseCost: 2,
                costMultiplier: 2.5,
                currentLevel: 0,
                maxLevel: 10,
                apply: (game) => {
                    game.prestigePointsBonus += 0.25;
                }
            },
            {
                id: 'starting_energy',
                name: 'Residual Energy',
                icon: '⚡',
                description: 'Start each run with bonus energy',
                effect: 'Start with +100 energy per level',
                baseCost: 3,
                costMultiplier: 2,
                currentLevel: 0,
                maxLevel: 15,
                apply: (game) => {
                    game.startingEnergy += 100;
                }
            },
            {
                id: 'starting_multiplier',
                name: 'Quantum Resonance',
                icon: '⚛️',
                description: 'Start with increased global multiplier',
                effect: '+50% global mult per level',
                baseCost: 5,
                costMultiplier: 3,
                currentLevel: 0,
                maxLevel: 10,
                apply: (game) => {
                    game.startingMultiplier += 0.5;
                }
            },
            {
                id: 'auto_buy_generators',
                name: 'Auto-Purchase Protocol',
                icon: '🤖',
                description: 'Automatically purchase generators',
                effect: 'Unlock auto-buy for generators',
                baseCost: 10,
                costMultiplier: 1,
                currentLevel: 0,
                maxLevel: 1,
                apply: (game) => {
                    game.autoBuyGenerators = true;
                }
            },
            {
                id: 'offline_progress',
                name: 'Temporal Cache',
                icon: '⏳',
                description: 'Earn energy while offline',
                effect: '+10% offline production per level',
                baseCost: 8,
                costMultiplier: 2.5,
                currentLevel: 0,
                maxLevel: 10,
                apply: (game) => {
                    game.offlineProductionRate += 0.1;
                }
            },
            {
                id: 'crit_start',
                name: 'Lucky Charm',
                icon: '🍀',
                description: 'Start with increased crit chance',
                effect: '+5% crit chance per level',
                baseCost: 6,
                costMultiplier: 2.5,
                currentLevel: 0,
                maxLevel: 5,
                apply: (game) => {
                    game.startingCritChance += 0.05;
                }
            },
            {
                id: 'powerup_discount',
                name: 'Power Efficiency',
                icon: '🔋',
                description: 'Reduce power-up costs',
                effect: '-10% power-up cost per level',
                baseCost: 7,
                costMultiplier: 2,
                currentLevel: 0,
                maxLevel: 5,
                apply: (game) => {
                    game.powerupCostReduction += 0.1;
                }
            },
            {
                id: 'event_frequency',
                name: 'Event Magnet',
                icon: '🎁',
                description: 'Increase special event frequency',
                effect: '+25% event spawn rate per level',
                baseCost: 5,
                costMultiplier: 2.5,
                currentLevel: 0,
                maxLevel: 8,
                apply: (game) => {
                    game.eventSpawnBonus += 0.25;
                }
            },
            {
                id: 'combo_keeper',
                name: 'Combo Preservation',
                icon: '🔥',
                description: 'Combo window lasts longer',
                effect: '+1s combo window per level',
                baseCost: 4,
                costMultiplier: 2,
                currentLevel: 0,
                maxLevel: 10,
                apply: (game) => {
                    game.comboWindowBonus += 1000;
                }
            }
        ];
    }

    calculatePrestigePoints(totalEnergy) {
        // Formula: sqrt(totalEnergy / 1000)
        if (totalEnergy < 1000) return 0;
        return Math.floor(Math.sqrt(totalEnergy / 1000));
    }

    calculatePrestigeMultiplier(prestigePoints) {
        // 1% bonus per prestige point
        return 1 + (prestigePoints * 0.01);
    }

    canPrestige(game) {
        return this.calculatePrestigePoints(game.stats.totalEnergy) > 0;
    }

    getPrestigeGain(game) {
        const baseGain = this.calculatePrestigePoints(game.stats.totalEnergy);
        const bonus = game.prestigePointsBonus || 0;
        return Math.floor(baseGain * (1 + bonus));
    }

    performPrestige(game) {
        if (!this.canPrestige(game)) return false;

        const pointsGained = this.getPrestigeGain(game);
        
        // Save prestige stats
        const oldPrestigeCount = game.prestigeCount;
        const oldPrestigePoints = game.prestigePoints;
        
        // Reset game but keep prestige data
        game.prestigePoints += pointsGained;
        game.prestigeCount++;
        
        // Calculate new prestige multiplier
        game.prestigeMultiplier = this.calculatePrestigeMultiplier(game.prestigePoints);
        
        // Reset all non-prestige systems
        game.energy = game.startingEnergy || 0;
        game.clickPower = 1;
        game.globalMultiplier = 1 + (game.startingMultiplier || 0);
        game.comboCount = 0;
        game.comboWindow = 2000 + (game.comboWindowBonus || 0);
        game.comboBonus = 0;
        game.critChance = game.startingCritChance || 0;
        game.critMultiplier = 2;
        game.autoClickersPerSecond = 0;
        game.level = 1;
        
        // Reset stats (keep prestige-related ones)
        game.stats.totalClicks = 0;
        game.stats.totalEnergy = 0;
        game.stats.highestCombo = 0;
        game.stats.criticalClicks = 0;
        
        // Reset managers
        upgradesManager.reset();
        generatorsManager.reset();
        achievementsManager.reset(true); // Keep prestige achievements
        powerupsManager.reset();
        milestonesManager.reset();
        
        // Show notification
        notifications.success(
            '🌟 ASCENSION COMPLETE!',
            `+${pointsGained} Prestige Points! Total: ${game.prestigePoints}`,
            5000
        );
        
        // Create massive celebration
        const prestigeBtn = document.getElementById('prestige-btn');
        if (prestigeBtn) {
            particleSystem.createCelebration(prestigeBtn);
        }
        
        return true;
    }

    getCost(upgrade) {
        return Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, upgrade.currentLevel));
    }

    canAfford(upgrade, prestigePoints) {
        return prestigePoints >= this.getCost(upgrade);
    }

    isMaxed(upgrade) {
        return upgrade.currentLevel >= upgrade.maxLevel;
    }

    purchase(upgrade, game) {
        if (this.isMaxed(upgrade)) return false;
        if (!this.canAfford(upgrade, game.prestigePoints)) return false;

        const cost = this.getCost(upgrade);
        game.prestigePoints -= cost;
        upgrade.currentLevel++;
        upgrade.apply(game);

        // Create burst effect
        const upgradeCard = document.querySelector(`[data-prestige-upgrade-id="${upgrade.id}"]`);
        if (upgradeCard) {
            const rect = upgradeCard.getBoundingClientRect();
            particleSystem.createBurst(
                rect.left + rect.width / 2,
                rect.top + rect.height / 2,
                20,
                '#ff00ff'
            );
        }

        notifications.success(
            '🌟 Prestige Upgrade!',
            `${upgrade.name} Level ${upgrade.currentLevel}`
        );

        return true;
    }

    getSaveData() {
        const data = {};
        this.prestigeUpgrades.forEach(upgrade => {
            data[upgrade.id] = upgrade.currentLevel;
        });
        return data;
    }

    loadSaveData(data) {
        if (!data) return;
        Object.keys(data).forEach(id => {
            const upgrade = this.prestigeUpgrades.find(u => u.id === id);
            if (upgrade) {
                upgrade.currentLevel = data[id];
            }
        });
    }
}

const prestigeManager = new PrestigeManager();
