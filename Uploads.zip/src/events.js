// Special Events System

class EventsManager {
    constructor() {
        this.eventTypes = [
            {
                id: 'bonus_energy',
                title: 'ENERGY SURGE',
                icon: '⚡',
                description: 'A surge of energy flows through the nexus!',
                duration: 30,
                reward: (game) => {
                    const bonus = Math.floor(game.energy * 0.5);
                    game.energy += bonus;
                    return `+${this.formatNumber(bonus)} Energy!`;
                }
            },
            {
                id: 'double_production',
                title: 'PRODUCTION BOOST',
                icon: '🚀',
                description: 'All generators are working overtime!',
                duration: 60,
                reward: (game) => {
                    game.eventProductionBonus = 2;
                    setTimeout(() => {
                        game.eventProductionBonus = 1;
                    }, 60000);
                    return 'Double production for 60s!';
                }
            },
            {
                id: 'free_upgrades',
                title: 'TECH BREAKTHROUGH',
                icon: '🔬',
                description: 'Upgrades are temporarily free!',
                duration: 45,
                reward: (game) => {
                    game.freeUpgrades = true;
                    setTimeout(() => {
                        game.freeUpgrades = false;
                    }, 45000);
                    return 'Free upgrades for 45s!';
                }
            },
            {
                id: 'mega_combo',
                title: 'COMBO FRENZY',
                icon: '🔥',
                description: 'Combo power is supercharged!',
                duration: 40,
                reward: (game) => {
                    const oldBonus = game.comboBonus;
                    game.comboBonus *= 3;
                    setTimeout(() => {
                        game.comboBonus = oldBonus;
                    }, 40000);
                    return '3x combo bonus for 40s!';
                }
            },
            {
                id: 'crit_spree',
                title: 'LUCKY MOMENT',
                icon: '🍀',
                description: 'Lady luck smiles upon you!',
                duration: 30,
                reward: (game) => {
                    const oldCrit = game.critChance;
                    game.critChance = Math.min(1, game.critChance + 0.5);
                    setTimeout(() => {
                        game.critChance = oldCrit;
                    }, 30000);
                    return '+50% crit chance for 30s!';
                }
            },
            {
                id: 'prestige_boost',
                title: 'COSMIC ALIGNMENT',
                icon: '🌠',
                description: 'The stars align in your favor!',
                duration: 20,
                reward: (game) => {
                    const points = Math.floor(game.prestigePoints * 0.1) + 1;
                    game.prestigePoints += points;
                    return `+${points} Prestige Points!`;
                }
            },
            {
                id: 'instant_levels',
                title: 'EXPERIENCE RUSH',
                icon: '⬆️',
                description: 'Massive experience gain incoming!',
                duration: 15,
                reward: (game) => {
                    const levels = Math.floor(Math.random() * 3) + 1;
                    game.level += levels;
                    return `+${levels} Levels!`;
                }
            },
            {
                id: 'golden_click',
                title: 'GOLDEN OPPORTUNITY',
                icon: '✨',
                description: 'Next 10 clicks give massive rewards!',
                duration: 20,
                reward: (game) => {
                    game.goldenClicksRemaining = 10;
                    return 'Next 10 clicks = 100x reward!';
                }
            },
            {
                id: 'achievement_hunter',
                title: 'ACHIEVEMENT BONUS',
                icon: '🏆',
                description: 'Achievement rewards doubled temporarily!',
                duration: 120,
                reward: (game) => {
                    // Check and potentially unlock random achievement progress
                    return 'Achievement rewards doubled!';
                }
            },
            {
                id: 'mystery_box',
                title: 'MYSTERY REWARD',
                icon: '🎁',
                description: 'A mystery box appears...',
                duration: 25,
                reward: (game) => {
                    const rewards = [
                        () => { 
                            const bonus = Math.floor(game.energy * 0.75); 
                            game.energy += bonus; 
                            return `+${this.formatNumber(bonus)} Energy!`;
                        },
                        () => { 
                            game.clickPower *= 2; 
                            setTimeout(() => game.clickPower /= 2, 60000); 
                            return 'Double click power for 60s!';
                        },
                        () => { 
                            const pp = Math.floor(Math.random() * 5) + 1; 
                            game.prestigePoints += pp; 
                            return `+${pp} Prestige Points!`;
                        },
                        () => { 
                            game.level += 2; 
                            return '+2 Levels!';
                        },
                        () => { 
                            game.globalMultiplier *= 1.5; 
                            return '+50% global multiplier (permanent)!';
                        }
                    ];
                    const reward = rewards[Math.floor(Math.random() * rewards.length)];
                    return reward();
                }
            }
        ];
        
        this.currentEvent = null;
        this.eventTimer = 0;
        this.nextEventTime = this.getNextEventTime();
    }

    getNextEventTime() {
        // Random time between 2-5 minutes
        return (120 + Math.random() * 180) * 1000;
    }

    update(deltaTime, game) {
        if (this.currentEvent) {
            this.eventTimer -= deltaTime * 1000;
            if (this.eventTimer <= 0) {
                this.expireEvent();
            }
        } else {
            this.nextEventTime -= deltaTime * 1000;
            if (this.nextEventTime <= 0) {
                this.spawnEvent(game);
            }
        }
    }

    spawnEvent(game) {
        const eventType = this.eventTypes[Math.floor(Math.random() * this.eventTypes.length)];
        
        // Apply event spawn bonus
        const spawnBonus = game.eventSpawnBonus || 0;
        const duration = eventType.duration * (1 + spawnBonus);
        
        this.currentEvent = {
            ...eventType,
            duration: duration,
            game: game
        };
        this.eventTimer = duration * 1000;
        
        notifications.warning(
            '🎁 Special Event!',
            eventType.title,
            4000
        );
    }

    claimEvent() {
        if (!this.currentEvent) return;
        
        const result = this.currentEvent.reward(this.currentEvent.game);
        
        notifications.success(
            '✨ Event Claimed!',
            result,
            4000
        );
        
        this.currentEvent.game.stats.eventsCompleted = (this.currentEvent.game.stats.eventsCompleted || 0) + 1;
        
        this.currentEvent = null;
        this.nextEventTime = this.getNextEventTime();
    }

    expireEvent() {
        if (!this.currentEvent) return;
        
        notifications.warning(
            '⏱️ Event Expired',
            `${this.currentEvent.title} has ended`
        );
        
        this.currentEvent = null;
        this.nextEventTime = this.getNextEventTime();
    }

    formatNumber(num) {
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
        return Math.floor(num).toString();
    }

    reset() {
        this.currentEvent = null;
        this.eventTimer = 0;
        this.nextEventTime = this.getNextEventTime();
    }

    getSaveData() {
        return {
            currentEvent: this.currentEvent ? {
                id: this.currentEvent.id,
                timer: this.eventTimer
            } : null,
            nextEventTime: this.nextEventTime
        };
    }

    loadSaveData(data, game) {
        if (!data) return;
        
        if (data.currentEvent) {
            const eventType = this.eventTypes.find(e => e.id === data.currentEvent.id);
            if (eventType) {
                this.currentEvent = { ...eventType, game: game };
                this.eventTimer = data.currentEvent.timer || 0;
            }
        }
        
        this.nextEventTime = data.nextEventTime || this.getNextEventTime();
    }
}

const eventsManager = new EventsManager();
