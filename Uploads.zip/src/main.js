// Main Initialization

// Detect if user is on a mobile device
const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) || 
                 (navigator.maxTouchPoints && navigator.maxTouchPoints > 1);

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', () => {
    console.log('%c🎮 NEON NEXUS 🎮', 'font-size: 24px; color: #00ffff; font-weight: bold; text-shadow: 0 0 10px #00ffff');
    console.log('%cThe Ultimate Idle Experience', 'font-size: 14px; color: #ff00ff; text-shadow: 0 0 10px #ff00ff');
    
    if (isMobile) {
        console.log('%c📱 Mobile mode enabled', 'color: #00ff00; font-weight: bold');
    }
    
    // Show welcome notification
    setTimeout(() => {
        if (game.stats.playTime === 0) {
            notifications.success(
                '🌟 Welcome to Neon Nexus!',
                'Click the glowing orb to generate energy and begin your journey!',
                5000
            );
        } else {
            notifications.success(
                '✨ Welcome Back!',
                `Level ${game.level} | ${game.formatNumber(game.energy)} Energy`,
                3000
            );
        }
    }, 500);
    
    // Initialize UI
    initializeUI();
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Space bar to click
        if (e.code === 'Space' && !e.repeat) {
            e.preventDefault();
            const btn = document.getElementById('main-click-btn');
            const rect = btn.getBoundingClientRect();
            const x = rect.left + rect.width / 2;
            const y = rect.top + rect.height / 2;
            game.click(x, y);
            
            // Visual feedback
            btn.style.transform = 'scale(0.95)';
            setTimeout(() => {
                btn.style.transform = '';
            }, 100);
        }
        
        // Tab shortcuts
        if (e.ctrlKey || e.metaKey) {
            switch(e.key) {
                case 's':
                    e.preventDefault();
                    game.saveGame();
                    notifications.success('Saved!', 'Game saved');
                    break;
                case 'e':
                    e.preventDefault();
                    game.exportSave();
                    break;
            }
        }
        
        // Number keys for tabs
        if (e.key >= '1' && e.key <= '5' && !e.ctrlKey && !e.metaKey) {
            const tabButtons = document.querySelectorAll('.tab-btn');
            const index = parseInt(e.key) - 1;
            if (tabButtons[index]) {
                tabButtons[index].click();
            }
        }
    });
    
    // Prevent accidental navigation
    window.addEventListener('beforeunload', (e) => {
        game.saveGame();
    });
    
    // ===== MOBILE TOUCH SUPPORT =====
    
    // Prevent default touch behaviors to avoid zoom and scrolling issues
    if (isMobile) {
        document.body.style.overflow = 'auto';
        document.body.style.position = 'relative';
        
        // Prevent pull-to-refresh on mobile
        document.body.addEventListener('touchmove', (e) => {
            if (e.target === document.body) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // Prevent double-tap zoom on specific elements
        const preventZoomElements = document.querySelectorAll('.main-click-btn, .tab-btn, .upgrade-card, .generator-card, .powerup-card, .setting-btn');
        preventZoomElements.forEach(element => {
            element.addEventListener('touchend', (e) => {
                e.preventDefault();
                element.click();
            }, { passive: false });
        });
    }
    
    // Add touch and click visual effects
    const mainClickBtn = document.getElementById('main-click-btn');
    
    // Handle both mouse and touch events
    const handlePressStart = (e) => {
        e.currentTarget.style.transform = 'scale(0.95)';
        e.currentTarget.style.transition = 'transform 0.1s ease';
    };
    
    const handlePressEnd = (e) => {
        e.currentTarget.style.transform = '';
    };
    
    // Mouse events
    mainClickBtn.addEventListener('mousedown', handlePressStart);
    mainClickBtn.addEventListener('mouseup', handlePressEnd);
    mainClickBtn.addEventListener('mouseleave', handlePressEnd);
    
    // Touch events for mobile
    mainClickBtn.addEventListener('touchstart', (e) => {
        handlePressStart(e);
        
        // Get touch coordinates
        const touch = e.touches[0];
        const rect = e.currentTarget.getBoundingClientRect();
        const x = touch.clientX;
        const y = touch.clientY;
        
        // Trigger game click
        game.click(x, y);
    }, { passive: true });
    
    mainClickBtn.addEventListener('touchend', handlePressEnd, { passive: true });
    mainClickBtn.addEventListener('touchcancel', handlePressEnd, { passive: true });
    
    // Animate numbers on hover
    const animateNumber = (element, start, end, duration = 1000) => {
        const startTime = performance.now();
        
        const update = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const current = start + (end - start) * progress;
            element.textContent = game.formatNumber(current);
            
            if (progress < 1) {
                requestAnimationFrame(update);
            }
        };
        
        requestAnimationFrame(update);
    };
    
    // Easter eggs and fun messages
    const easterEggs = [
        { clicks: 100, message: '💯 Century Club!' },
        { clicks: 500, message: '🔥 You\\'re on fire!' },
        { clicks: 1000, message: '🎯 Thousand clicks! Legend!' },
        { clicks: 5000, message: '🚀 To the moon!' },
        { clicks: 10000, message: '⚡ UNSTOPPABLE!' },
        { energy: 1000000, message: '💎 Million Energy Club!' },
        { energy: 1000000000, message: '👑 Billion Energy Royalty!' },
        { level: 20, message: '⭐ Rising Star!' },
        { level: 50, message: '🌟 Superstar Status!' },
        { level: 100, message: '💫 LEGENDARY!' }
    ];
    
    let triggeredEasterEggs = new Set();
    
    setInterval(() => {
        easterEggs.forEach((egg, index) => {
            if (triggeredEasterEggs.has(index)) return;
            
            let triggered = false;
            
            if (egg.clicks && game.stats.totalClicks >= egg.clicks) {
                triggered = true;
            } else if (egg.energy && game.stats.totalEnergy >= egg.energy) {
                triggered = true;
            } else if (egg.level && game.level >= egg.level) {
                triggered = true;
            }
            
            if (triggered) {
                triggeredEasterEggs.add(index);
                notifications.info('🎉 Achievement!', egg.message, 3000);
                
                // Celebration effect on main button
                const btn = document.getElementById('main-click-btn');
                particleSystem.createCelebration(btn);
            }
        });
    }, 2000);
    
    // Tips system
    const tips = [
        'Tip: Press SPACE to click!',
        'Tip: Use number keys 1-5 to switch tabs quickly!',
        'Tip: Combos increase your click power - keep clicking!',
        'Tip: Generators provide passive income even when you\\'re away!',
        'Tip: Prestige gives permanent bonuses - don\\'t be afraid to reset!',
        'Tip: Power-ups can dramatically boost your progress!',
        'Tip: Watch for special events - they give huge rewards!',
        'Tip: Achievements grant permanent bonuses!',
        'Tip: Level up to unlock new features!',
        'Tip: Critical hits deal massive damage - upgrade your crit chance!',
        'Tip: Auto-clickers work even when you\'re not clicking!',
        'Tip: Higher combos = higher rewards!',
        'Tip: Save your game regularly with Ctrl+S!',
        'Tip: Export your save to backup your progress!',
        'Tip: Milestones give permanent bonuses automatically!'
    ];
    
    let tipIndex = 0;
    setInterval(() => {
        if (Math.random() < 0.3) { // 30% chance every interval
            notifications.info('💡', tips[tipIndex], 4000);
            tipIndex = (tipIndex + 1) % tips.length;
        }
    }, 60000); // Every minute
    
    // Performance monitoring
    let fps = 0;
    let lastFrameTime = performance.now();
    
    const monitorPerformance = () => {
        const currentTime = performance.now();
        fps = 1000 / (currentTime - lastFrameTime);
        lastFrameTime = currentTime;
        
        // Log warnings for low FPS
        if (fps < 30 && fps > 0) {
            console.warn('Low FPS detected:', Math.floor(fps));
        }
        
        requestAnimationFrame(monitorPerformance);
    };
    
    monitorPerformance();
    
    // Mobile particle cleanup for performance
    if (isMobile) {
        setInterval(() => {
            if (particleSystem && particleSystem.cleanup) {
                particleSystem.cleanup();
            }
        }, 2000); // Clean up every 2 seconds on mobile
    }
    
    // Debug mode (toggle with Ctrl+Shift+D)
    let debugMode = false;
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.shiftKey && e.key === 'D') {
            debugMode = !debugMode;
            console.log('Debug mode:', debugMode ? 'ON' : 'OFF');
            
            if (debugMode) {
                // Add debug overlay
                const debugOverlay = document.createElement('div');
                debugOverlay.id = 'debug-overlay';
                debugOverlay.style.cssText = `
                    position: fixed;
                    top: 10px;
                    left: 10px;
                    background: rgba(0, 0, 0, 0.8);
                    color: #00ff00;
                    padding: 10px;
                    font-family: monospace;
                    font-size: 12px;
                    z-index: 10000;
                    border: 2px solid #00ff00;
                    border-radius: 5px;
                `;
                document.body.appendChild(debugOverlay);
                
                setInterval(() => {
                    if (debugMode) {
                        const overlay = document.getElementById('debug-overlay');
                        if (overlay) {
                            overlay.innerHTML = `
                                FPS: ${Math.floor(fps)}<br>
                                Energy: ${game.formatNumber(game.energy)}<br>
                                Energy/sec: ${game.formatNumber(generatorsManager.getTotalProduction(game))}<br>
                                Clicks: ${game.stats.totalClicks}<br>
                                Combo: ${game.comboCount}<br>
                                Level: ${game.level}<br>
                                Prestige: ${game.prestigeCount}<br>
                            `;
                        }
                    }
                }, 100);
            } else {
                const overlay = document.getElementById('debug-overlay');
                if (overlay) overlay.remove();
            }
        }
    });
    
    // Console commands for testing
    window.cheat = {
        addEnergy: (amount) => {
            game.energy += amount;
            game.stats.totalEnergy += amount;
            console.log(`Added ${amount} energy`);
        },
        addPrestigePoints: (amount) => {
            game.prestigePoints += amount;
            console.log(`Added ${amount} prestige points`);
        },
        setLevel: (level) => {
            game.level = level;
            console.log(`Set level to ${level}`);
        },
        unlockAll: () => {
            achievementsManager.achievements.forEach(a => {
                if (!a.unlocked) {
                    a.unlocked = true;
                    a.apply(game);
                }
            });
            console.log('Unlocked all achievements');
        },
        maxAll: () => {
            upgradesManager.upgrades.forEach(u => {
                while (!upgradesManager.isMaxed(u)) {
                    u.currentLevel++;
                    u.apply(game);
                }
            });
            console.log('Maxed all upgrades');
        }
    };
    
    console.log('%cDebug commands available:', 'color: #00ffff; font-weight: bold');
    console.log('%ccheat.addEnergy(amount)', 'color: #00ff00');
    console.log('%ccheat.addPrestigePoints(amount)', 'color: #00ff00');
    console.log('%ccheat.setLevel(level)', 'color: #00ff00');
    console.log('%ccheat.unlockAll()', 'color: #00ff00');
    console.log('%ccheat.maxAll()', 'color: #00ff00');
    console.log('%cPress Ctrl+Shift+D for debug overlay', 'color: #ffff00');
    
    // Celebrate milestones
    let lastLevel = game.level;
    setInterval(() => {
        if (game.level > lastLevel) {
            const mainBtn = document.getElementById('main-click-btn');
            particleSystem.createCelebration(mainBtn);
            lastLevel = game.level;
        }
    }, 1000);
    
    // Auto-save indicator
    setInterval(() => {
        const timeSinceLastSave = Date.now() - game.lastSave;
        if (timeSinceLastSave < 1000) {
            // Flash a save indicator
            const saveBtn = document.getElementById('save-btn');
            saveBtn.style.borderColor = '#00ff00';
            setTimeout(() => {
                saveBtn.style.borderColor = '';
            }, 500);
        }
    }, 500);
    
    console.log('%c✅ Game initialized successfully!', 'color: #00ff00; font-weight: bold; font-size: 14px');
    console.log('%c🎮 Have fun playing Neon Nexus!', 'color: #ff00ff; font-weight: bold; font-size: 14px');
});
