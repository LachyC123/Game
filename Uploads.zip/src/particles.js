// Particle Effects System

// Detect mobile device for performance optimization
const isMobileDevice = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) || 
                       (navigator.maxTouchPoints && navigator.maxTouchPoints > 1);

class ParticleSystem {
    constructor() {
        this.container = document.getElementById('particle-container');
        // Reduce particle count on mobile for better performance
        this.isMobile = isMobileDevice;
        this.particleMultiplier = this.isMobile ? 0.4 : 1; // 40% particles on mobile
        
        if (this.isMobile) {
            console.log('🎨 Particle system optimized for mobile');
        }
    }

    // Create floating text particle (for click rewards)
    createTextParticle(x, y, text, color = '#00ffff') {
        // Throttle text particles on mobile
        if (this.isMobile && Math.random() > 0.5) {
            return; // Skip 50% of text particles on mobile
        }
        
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.textContent = text;
        particle.style.left = x + 'px';
        particle.style.top = y + 'px';
        particle.style.color = color;
        particle.style.textShadow = `0 0 10px ${color}`;
        
        this.container.appendChild(particle);
        
        setTimeout(() => {
            particle.remove();
        }, 1500);
    }

    // Create burst effect (for achievements, upgrades)
    createBurst(x, y, count = 20, color = '#00ffff') {
        // Reduce burst particles on mobile
        const adjustedCount = Math.floor(count * this.particleMultiplier);
        
        for (let i = 0; i < adjustedCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle-effect';
            
            const angle = (Math.PI * 2 * i) / adjustedCount;
            const distance = 50 + Math.random() * 50;
            const tx = Math.cos(angle) * distance;
            const ty = Math.sin(angle) * distance;
            
            particle.style.left = x + 'px';
            particle.style.top = y + 'px';
            particle.style.background = color;
            particle.style.boxShadow = `0 0 10px ${color}`;
            particle.style.setProperty('--tx', tx + 'px');
            particle.style.setProperty('--ty', ty + 'px');
            
            this.container.appendChild(particle);
            
            setTimeout(() => {
                particle.remove();
            }, 800);
        }
    }

    // Create celebration effect (for milestones, prestige)
    createCelebration(element) {
        element.classList.add('celebrate');
        
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        // Create multiple bursts with different colors
        const colors = ['#00ffff', '#ff00ff', '#00ff00', '#ffff00', '#0080ff'];
        // Reduce number of color bursts on mobile
        const colorsToUse = this.isMobile ? colors.slice(0, 3) : colors;
        
        colorsToUse.forEach((color, index) => {
            setTimeout(() => {
                this.createBurst(centerX, centerY, this.isMobile ? 15 : 30, color);
            }, index * 100);
        });
        
        setTimeout(() => {
            element.classList.remove('celebrate');
        }, 600);
    }

    // Create click ripple effect
    createRipple(x, y) {
        // Simplified ripple effect on mobile
        if (this.isMobile && Math.random() > 0.6) {
            return; // Skip 40% of ripples on mobile
        }
        
        const ripple = document.createElement('div');
        ripple.style.position = 'absolute';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.style.width = '10px';
        ripple.style.height = '10px';
        ripple.style.borderRadius = '50%';
        ripple.style.border = '2px solid #00ffff';
        ripple.style.pointerEvents = 'none';
        ripple.style.animation = 'rippleExpand 0.6s ease-out';
        
        this.container.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }
    
    // Clean up old particles for mobile performance
    cleanup() {
        if (this.isMobile && this.container.children.length > 20) {
            // Remove oldest particles if too many exist
            while (this.container.children.length > 20) {
                this.container.firstChild.remove();
            }
        }
    }
}

// Add ripple animation to CSS dynamically
if (!document.getElementById('ripple-style')) {
    const style = document.createElement('style');
    style.id = 'ripple-style';
    style.textContent = `
        @keyframes rippleExpand {
            from {
                transform: translate(-50%, -50%) scale(1);
                opacity: 1;
            }
            to {
                transform: translate(-50%, -50%) scale(10);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

const particleSystem = new ParticleSystem();
