// Core Game Engine

class Game {
    constructor() {
        // Core resources
        this.energy = 0;
        this.clickPower = 1;
        this.globalMultiplier = 1;
        
        // Combo system
        this.comboCount = 0;
        this.comboWindow = 2000; // milliseconds
        this.comboTimeout = null;
        this.comboBonus = 0; // Additional combo bonus from upgrades
        this.comboFrozen = false; // From power-up
        this.comboWindowBonus = 0; // From prestige
        
        // Click modifiers
        this.clickPowerMultiplier = 1; // From power-ups
        this.critChance = 0;
        this.critMultiplier = 2;
        this.startingCritChance = 0;
        this.guaranteedCrit = false; // From power-up
        
        // Production modifiers
        this.productionMultiplier = 1; // From power-ups
        this.energyGainMultiplier = 1; // From power-ups
        this.eventProductionBonus = 1; // From events
        
        // Auto-clickers
        this.autoClickersPerSecond = 0;
        this.autoClickerMultiplier = 1; // From power-ups
        
        // Cost modifiers
        this.costReduction = 0; // From power-ups
        this.powerupCostReduction = 0; // From prestige
        this.freeUpgrades = false; // From events
        
        // Prestige system
        this.prestigeCount = 0;
        this.prestigePoints = 0;
        this.prestigeMultiplier = 1;
        this.prestigeBonus = 0;
        this.prestigePointsBonus = 0;
        this.startingEnergy = 0;
        this.startingMultiplier = 0;
        
        // Level system
        this.level = 1;
        this.experience = 0;
        this.experienceToNextLevel = 100;
        
        // Special mechanics
        this.goldenClicksRemaining = 0; // From events
        this.autoBuyGenerators = false; // From prestige
        this.offlineProductionRate = 0; // From prestige
        this.powerupDurationBonus = 0; // From achievements
        this.eventSpawnBonus = 0; // From achievements/prestige
        
        // Statistics
        this.stats = {
            totalClicks: 0,
            totalEnergy: 0,
            playTime: 0,
            highestCombo: 0,
            criticalClicks: 0,
            powerupsUsed: 0,
            eventsCompleted: 0
        };
        
        // Game state
        this.lastUpdate = Date.now();
        this.lastSave = Date.now();
        this.autoSaveInterval = 30000; // 30 seconds
        
        // Initialize
        this.init();
    }
    
    init() {
        // Load saved game if exists
        this.loadGame();
        
        // Start game loop
        this.gameLoop();
        
        // Auto-save
        setInterval(() => this.saveGame(), this.autoSaveInterval);
    }
    
    gameLoop() {
        const now = Date.now();
        const deltaTime = (now - this.lastUpdate) / 1000; // seconds
        this.lastUpdate = now;
        
        // Update game logic
        this.update(deltaTime);
        
        // Continue loop
        requestAnimationFrame(() => this.gameLoop());
    }
    
    update(deltaTime) {
        // Update play time
        this.stats.playTime += deltaTime;
        
        // Generate passive income
        this.generatePassiveIncome(deltaTime);
        
        // Auto-clickers
        this.processAutoClickers(deltaTime);
        
        // Update power-ups
        powerupsManager.update(deltaTime, this);
        
        // Update events
        eventsManager.update(deltaTime, this);
        
        // Check achievements
        achievementsManager.check(this);
        
        // Check milestones
        milestonesManager.check(this);
        
        // Update level
        this.updateLevel();
        
        // Update UI
        if (typeof updateUI === 'function') {
            updateUI(this);
        }
    }
    
    generatePassiveIncome(deltaTime) {
        const production = generatorsManager.getTotalProduction(this);
        const modifiedProduction = production * 
            this.productionMultiplier * 
            this.eventProductionBonus *
            this.energyGainMultiplier;
        
        const energyGained = modifiedProduction * deltaTime;
        this.addEnergy(energyGained);
    }
    
    processAutoClickers(deltaTime) {
        if (this.autoClickersPerSecond > 0) {
            const clicks = this.autoClickersPerSecond * this.autoClickerMultiplier * deltaTime;
            const wholeClicks = Math.floor(clicks);
            
            for (let i = 0; i < wholeClicks; i++) {
                this.click(false, true); // Silent auto-clicks
            }
        }
    }
    
    click(x = null, y = null, isAuto = false) {
        // Calculate click value
        let clickValue = this.clickPower * this.clickPowerMultiplier;
        
        // Check for critical hit
        const isCrit = this.guaranteedCrit || Math.random() < this.critChance;
        if (isCrit) {
            clickValue *= this.critMultiplier;
            this.stats.criticalClicks++;
            
            if (!isAuto && x && y) {
                // Visual feedback for crit
                particleSystem.createTextParticle(x, y, 'CRIT!', '#ff00ff');
            }
        }
        
        // Golden click bonus
        if (this.goldenClicksRemaining > 0) {
            clickValue *= 100;
            this.goldenClicksRemaining--;
            
            if (!isAuto && x && y) {
                particleSystem.createTextParticle(x, y, 'GOLDEN!', '#ffd700');
            }
        }
        
        // Apply combo
        if (!this.comboFrozen) {
            this.comboCount++;
            this.resetComboTimer();
        } else {
            this.comboCount++;
        }
        
        if (this.comboCount > this.stats.highestCombo) {
            this.stats.highestCombo = this.comboCount;
        }
        
        const comboMultiplier = 1 + (this.comboCount * 0.01) + this.comboBonus;
        clickValue *= comboMultiplier;
        
        // Apply global multiplier
        clickValue *= this.globalMultiplier;
        
        // Apply prestige multiplier
        clickValue *= this.prestigeMultiplier;
        
        // Apply energy gain multiplier
        clickValue *= this.energyGainMultiplier;
        
        // Add energy
        this.addEnergy(clickValue);
        
        // Update stats
        this.stats.totalClicks++;
        
        // Add experience
        this.addExperience(1);
        
        // Visual feedback
        if (!isAuto && x && y) {
            particleSystem.createTextParticle(
                x, 
                y, 
                '+' + this.formatNumber(clickValue),
                isCrit ? '#ff00ff' : '#00ffff'
            );
            particleSystem.createRipple(x, y);
        }
    }
    
    resetComboTimer() {
        if (this.comboTimeout) {
            clearTimeout(this.comboTimeout);
        }
        
        if (!this.comboFrozen) {
            const window = this.comboWindow + this.comboWindowBonus;
            this.comboTimeout = setTimeout(() => {
                this.comboCount = 0;
            }, window);
        }
    }
    
    addEnergy(amount) {
        this.energy += amount;
        this.stats.totalEnergy += amount;
        
        // Auto-buy generators if unlocked
        if (this.autoBuyGenerators) {
            this.autoBuyGeneratorsFunction();
        }
    }
    
    autoBuyGeneratorsFunction() {
        generatorsManager.generators.forEach(generator => {
            if (generatorsManager.canAfford(generator, this.energy) &&
                generatorsManager.isUnlocked(generator, this.stats.totalEnergy)) {
                generatorsManager.purchase(generator, this);
            }
        });
    }
    
    addExperience(amount) {
        this.experience += amount;
        
        while (this.experience >= this.experienceToNextLevel) {
            this.levelUp();
        }
    }
    
    levelUp() {
        this.experience -= this.experienceToNextLevel;
        this.level++;
        this.experienceToNextLevel = Math.floor(100 * Math.pow(1.1, this.level - 1));
        
        // Level up rewards
        this.clickPower += this.level;
        this.globalMultiplier += 0.01;
        
        notifications.success(
            '\u2b50 LEVEL UP!',
            `Level ${this.level} - Click power +${this.level}!`
        );
        
        // Celebration effect
        const levelDisplay = document.getElementById('player-level');
        if (levelDisplay) {
            particleSystem.createCelebration(levelDisplay);
        }
    }
    
    updateLevel() {
        // Levels are updated through experience gain
    }
    
    formatNumber(num) {
        if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
        return Math.floor(num).toString();
    }
    
    formatTime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else if (minutes > 0) {
            return `${minutes}m ${secs}s`;
        } else {
            return `${secs}s`;
        }
    }
    
    saveGame() {
        const saveData = {
            version: '1.0',
            timestamp: Date.now(),
            game: {
                energy: this.energy,
                clickPower: this.clickPower,
                globalMultiplier: this.globalMultiplier,
                comboCount: this.comboCount,
                comboBonus: this.comboBonus,
                comboWindowBonus: this.comboWindowBonus,
                critChance: this.critChance,
                critMultiplier: this.critMultiplier,
                startingCritChance: this.startingCritChance,
                autoClickersPerSecond: this.autoClickersPerSecond,
                prestigeCount: this.prestigeCount,
                prestigePoints: this.prestigePoints,
                prestigeMultiplier: this.prestigeMultiplier,
                prestigeBonus: this.prestigeBonus,
                prestigePointsBonus: this.prestigePointsBonus,
                startingEnergy: this.startingEnergy,
                startingMultiplier: this.startingMultiplier,
                level: this.level,
                experience: this.experience,
                experienceToNextLevel: this.experienceToNextLevel,
                autoBuyGenerators: this.autoBuyGenerators,
                offlineProductionRate: this.offlineProductionRate,
                powerupDurationBonus: this.powerupDurationBonus,
                eventSpawnBonus: this.eventSpawnBonus,
                powerupCostReduction: this.powerupCostReduction,
                stats: this.stats
            },
            upgrades: upgradesManager.getSaveData(),
            generators: generatorsManager.getSaveData(),
            achievements: achievementsManager.getSaveData(),
            prestige: prestigeManager.getSaveData(),
            powerups: powerupsManager.getSaveData(),
            events: eventsManager.getSaveData(),
            milestones: milestonesManager.getSaveData()
        };
        
        localStorage.setItem('neonNexusSave', JSON.stringify(saveData));
        this.lastSave = Date.now();
        
        return saveData;
    }
    
    loadGame() {
        const saveDataStr = localStorage.getItem('neonNexusSave');
        if (!saveDataStr) return false;
        
        try {
            const saveData = JSON.parse(saveDataStr);
            
            // Load game state
            const game = saveData.game;
            this.energy = game.energy || 0;
            this.clickPower = game.clickPower || 1;
            this.globalMultiplier = game.globalMultiplier || 1;
            this.comboCount = game.comboCount || 0;
            this.comboBonus = game.comboBonus || 0;
            this.comboWindowBonus = game.comboWindowBonus || 0;
            this.critChance = game.critChance || 0;
            this.critMultiplier = game.critMultiplier || 2;
            this.startingCritChance = game.startingCritChance || 0;
            this.autoClickersPerSecond = game.autoClickersPerSecond || 0;
            this.prestigeCount = game.prestigeCount || 0;
            this.prestigePoints = game.prestigePoints || 0;
            this.prestigeMultiplier = game.prestigeMultiplier || 1;
            this.prestigeBonus = game.prestigeBonus || 0;
            this.prestigePointsBonus = game.prestigePointsBonus || 0;
            this.startingEnergy = game.startingEnergy || 0;
            this.startingMultiplier = game.startingMultiplier || 0;
            this.level = game.level || 1;
            this.experience = game.experience || 0;
            this.experienceToNextLevel = game.experienceToNextLevel || 100;
            this.autoBuyGenerators = game.autoBuyGenerators || false;
            this.offlineProductionRate = game.offlineProductionRate || 0;
            this.powerupDurationBonus = game.powerupDurationBonus || 0;
            this.eventSpawnBonus = game.eventSpawnBonus || 0;
            this.powerupCostReduction = game.powerupCostReduction || 0;
            this.stats = game.stats || {
                totalClicks: 0,
                totalEnergy: 0,
                playTime: 0,
                highestCombo: 0,
                criticalClicks: 0,
                powerupsUsed: 0,
                eventsCompleted: 0
            };
            
            // Load managers
            upgradesManager.loadSaveData(saveData.upgrades);
            generatorsManager.loadSaveData(saveData.generators);
            achievementsManager.loadSaveData(saveData.achievements);
            prestigeManager.loadSaveData(saveData.prestige);
            powerupsManager.loadSaveData(saveData.powerups);
            eventsManager.loadSaveData(saveData.events, this);
            milestonesManager.loadSaveData(saveData.milestones);
            
            // Re-apply all upgrades
            upgradesManager.upgrades.forEach(upgrade => {
                for (let i = 0; i < upgrade.currentLevel; i++) {
                    upgrade.apply(this);
                }
            });
            
            // Re-apply all prestige upgrades
            prestigeManager.prestigeUpgrades.forEach(upgrade => {
                for (let i = 0; i < upgrade.currentLevel; i++) {
                    upgrade.apply(this);
                }
            });
            
            // Re-apply all achievements
            achievementsManager.achievements.forEach(achievement => {
                if (achievement.unlocked) {
                    achievement.apply(this);
                }
            });
            
            // Re-apply all milestones
            milestonesManager.milestones.forEach(milestone => {
                if (milestone.unlocked) {
                    milestone.apply(this);
                }
            });
            
            // Calculate offline progress
            if (saveData.timestamp && this.offlineProductionRate > 0) {
                const offlineTime = (Date.now() - saveData.timestamp) / 1000;
                const production = generatorsManager.getTotalProduction(this);
                const offlineEnergy = production * offlineTime * this.offlineProductionRate;
                
                if (offlineEnergy > 0) {
                    this.energy += offlineEnergy;
                    this.stats.totalEnergy += offlineEnergy;
                    
                    notifications.success(
                        '🎉 Welcome Back!',
                        `You earned ${this.formatNumber(offlineEnergy)} energy while away (${this.formatTime(offlineTime)})`,
                        6000
                    );
                }
            }
            
            notifications.success('Game Loaded', 'Progress restored successfully!');
            return true;
        } catch (error) {
            console.error('Failed to load save:', error);
            notifications.error('Load Failed', 'Could not restore save data');
            return false;
        }
    }
    
    exportSave() {
        const saveData = this.saveGame();
        const encoded = btoa(JSON.stringify(saveData));
        
        // Copy to clipboard
        navigator.clipboard.writeText(encoded).then(() => {
            notifications.success('Exported!', 'Save data copied to clipboard');
        }).catch(() => {
            // Fallback: show in alert
            prompt('Copy this save data:', encoded);
        });
    }
    
    importSave(encoded) {
        try {
            const decoded = atob(encoded);
            const saveData = JSON.parse(decoded);
            
            localStorage.setItem('neonNexusSave', JSON.stringify(saveData));
            location.reload();
            
            return true;
        } catch (error) {
            console.error('Failed to import save:', error);
            notifications.error('Import Failed', 'Invalid save data');
            return false;
        }
    }
    
    hardReset() {
        if (confirm('Are you sure? This will delete ALL progress!')) {
            if (confirm('Really? This cannot be undone!')) {
                localStorage.removeItem('neonNexusSave');
                location.reload();
            }
        }
    }
}

// Create global game instance
const game = new Game();
