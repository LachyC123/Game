// Power-ups System

class PowerupsManager {
    constructor() {
        this.powerups = [
            {
                id: 'double_click',
                name: 'Double Power',
                icon: '×2️⃣',
                description: 'Double your click power',
                duration: 30,
                cooldown: 60,
                cost: 100,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.clickPowerMultiplier = (game.clickPowerMultiplier || 1) * 2;
                },
                deactivate: (game) => {
                    game.clickPowerMultiplier = (game.clickPowerMultiplier || 2) / 2;
                }
            },
            {
                id: 'triple_production',
                name: 'Production Surge',
                icon: '×3️⃣',
                description: 'Triple all energy production',
                duration: 45,
                cooldown: 90,
                cost: 250,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.productionMultiplier = (game.productionMultiplier || 1) * 3;
                },
                deactivate: (game) => {
                    game.productionMultiplier = (game.productionMultiplier || 3) / 3;
                }
            },
            {
                id: 'combo_freeze',
                name: 'Frozen Time',
                icon: '❄️',
                description: 'Combo never expires',
                duration: 60,
                cooldown: 120,
                cost: 500,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.comboFrozen = true;
                },
                deactivate: (game) => {
                    game.comboFrozen = false;
                }
            },
            {
                id: 'guaranteed_crit',
                name: 'Critical Strike',
                icon: '💥',
                description: '100% critical hit chance',
                duration: 20,
                cooldown: 120,
                cost: 300,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.guaranteedCrit = true;
                },
                deactivate: (game) => {
                    game.guaranteedCrit = false;
                }
            },
            {
                id: 'mega_multiplier',
                name: 'Mega Boost',
                icon: '🚀',
                description: '10x global multiplier',
                duration: 15,
                cooldown: 180,
                cost: 1000,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.globalMultiplier *= 10;
                },
                deactivate: (game) => {
                    game.globalMultiplier /= 10;
                }
            },
            {
                id: 'golden_touch',
                name: 'Golden Touch',
                icon: '✨',
                description: 'Gain 5x energy from all sources',
                duration: 30,
                cooldown: 150,
                cost: 750,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.energyGainMultiplier = (game.energyGainMultiplier || 1) * 5;
                },
                deactivate: (game) => {
                    game.energyGainMultiplier = (game.energyGainMultiplier || 5) / 5;
                }
            },
            {
                id: 'auto_clicker_boost',
                name: 'Turbo Clicker',
                icon: '⚡',
                description: 'Auto-clickers work 10x faster',
                duration: 40,
                cooldown: 100,
                cost: 600,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.autoClickerMultiplier = (game.autoClickerMultiplier || 1) * 10;
                },
                deactivate: (game) => {
                    game.autoClickerMultiplier = (game.autoClickerMultiplier || 10) / 10;
                }
            },
            {
                id: 'discount',
                name: 'Sale Event',
                icon: '💸',
                description: 'All purchases cost 50% less',
                duration: 60,
                cooldown: 180,
                cost: 500,
                active: false,
                remaining: 0,
                cooldownRemaining: 0,
                activate: (game) => {
                    game.costReduction = 0.5;
                },
                deactivate: (game) => {
                    game.costReduction = 0;
                }
            }
        ];
    }

    getCost(powerup, game) {
        const reduction = game.powerupCostReduction || 0;
        return Math.floor(powerup.cost * (1 - reduction));
    }

    getDuration(powerup, game) {
        const bonus = game.powerupDurationBonus || 0;
        return Math.floor(powerup.duration * (1 + bonus));
    }

    canUse(powerup, game) {
        return !powerup.active && 
               powerup.cooldownRemaining === 0 && 
               game.energy >= this.getCost(powerup, game);
    }

    activate(powerup, game) {
        if (!this.canUse(powerup, game)) return false;

        const cost = this.getCost(powerup, game);
        game.energy -= cost;

        powerup.active = true;
        powerup.remaining = this.getDuration(powerup, game);
        powerup.activate(game);

        game.stats.powerupsUsed = (game.stats.powerupsUsed || 0) + 1;

        // Create burst effect
        const powerupCard = document.querySelector(`[data-powerup-id="${powerup.id}"]`);
        if (powerupCard) {
            const rect = powerupCard.getBoundingClientRect();
            particleSystem.createBurst(
                rect.left + rect.width / 2,
                rect.top + rect.height / 2,
                25,
                '#ffff00'
            );
        }

        notifications.success(
            '⚡ Power-up Activated!',
            `${powerup.name} for ${powerup.remaining}s`
        );

        return true;
    }

    update(deltaTime, game) {
        this.powerups.forEach(powerup => {
            if (powerup.active) {
                powerup.remaining -= deltaTime;
                if (powerup.remaining <= 0) {
                    powerup.active = false;
                    powerup.remaining = 0;
                    powerup.cooldownRemaining = powerup.cooldown;
                    powerup.deactivate(game);
                    
                    notifications.info(
                        '⏱️ Power-up Expired',
                        `${powerup.name} has worn off`
                    );
                }
            } else if (powerup.cooldownRemaining > 0) {
                powerup.cooldownRemaining -= deltaTime;
                if (powerup.cooldownRemaining < 0) {
                    powerup.cooldownRemaining = 0;
                }
            }
        });
    }

    getActivePowerups() {
        return this.powerups.filter(p => p.active);
    }

    reset() {
        this.powerups.forEach(powerup => {
            if (powerup.active) {
                powerup.deactivate({ 
                    clickPowerMultiplier: 1,
                    productionMultiplier: 1,
                    globalMultiplier: 1,
                    energyGainMultiplier: 1,
                    autoClickerMultiplier: 1
                });
            }
            powerup.active = false;
            powerup.remaining = 0;
            powerup.cooldownRemaining = 0;
        });
    }

    getSaveData() {
        const data = {};
        this.powerups.forEach(powerup => {
            data[powerup.id] = {
                active: powerup.active,
                remaining: powerup.remaining,
                cooldownRemaining: powerup.cooldownRemaining
            };
        });
        return data;
    }

    loadSaveData(data) {
        if (!data) return;
        Object.keys(data).forEach(id => {
            const powerup = this.powerups.find(p => p.id === id);
            if (powerup && data[id]) {
                powerup.active = data[id].active || false;
                powerup.remaining = data[id].remaining || 0;
                powerup.cooldownRemaining = data[id].cooldownRemaining || 0;
            }
        });
    }
}

const powerupsManager = new PowerupsManager();
