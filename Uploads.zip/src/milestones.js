// Milestones System

class MilestonesManager {
    constructor() {
        this.milestones = [
            {
                id: 'energy_1000',
                name: 'Energy Milestone I',
                icon: '⚡',
                goal: 1000,
                type: 'totalEnergy',
                reward: 'Global mult +10%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 0.1;
                }
            },
            {
                id: 'energy_10000',
                name: 'Energy Milestone II',
                icon: '⚡⚡',
                goal: 10000,
                type: 'totalEnergy',
                reward: 'Global mult +25%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 0.25;
                }
            },
            {
                id: 'energy_100000',
                name: 'Energy Milestone III',
                icon: '⚡⚡⚡',
                goal: 100000,
                type: 'totalEnergy',
                reward: 'Global mult +50%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 0.5;
                }
            },
            {
                id: 'energy_1000000',
                name: 'Energy Milestone IV',
                icon: '🔥',
                goal: 1000000,
                type: 'totalEnergy',
                reward: 'Global mult +100%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 1;
                }
            },
            {
                id: 'clicks_500',
                name: 'Click Milestone I',
                icon: '👆',
                goal: 500,
                type: 'totalClicks',
                reward: 'Click power +10',
                unlocked: false,
                apply: (game) => {
                    game.clickPower += 10;
                }
            },
            {
                id: 'clicks_5000',
                name: 'Click Milestone II',
                icon: '👆👆',
                goal: 5000,
                type: 'totalClicks',
                reward: 'Click power +50',
                unlocked: false,
                apply: (game) => {
                    game.clickPower += 50;
                }
            },
            {
                id: 'clicks_50000',
                name: 'Click Milestone III',
                icon: '💎',
                goal: 50000,
                type: 'totalClicks',
                reward: 'Click power +250',
                unlocked: false,
                apply: (game) => {
                    game.clickPower += 250;
                }
            },
            {
                id: 'level_10',
                name: 'Level Up!',
                icon: '⭐',
                goal: 10,
                type: 'level',
                reward: 'Unlock special feature',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 0.2;
                }
            },
            {
                id: 'level_25',
                name: 'Quarter Century',
                icon: '⭐⭐',
                goal: 25,
                type: 'level',
                reward: 'Global mult +50%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 0.5;
                }
            },
            {
                id: 'level_50',
                name: 'Half Century',
                icon: '⭐⭐⭐',
                goal: 50,
                type: 'level',
                reward: 'Global mult +100%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 1;
                }
            },
            {
                id: 'level_100',
                name: 'Centurion',
                icon: '🌟',
                goal: 100,
                type: 'level',
                reward: 'Global mult +200%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 2;
                }
            },
            {
                id: 'generators_50',
                name: 'Generator Array',
                icon: '🔋',
                goal: 50,
                type: 'totalGenerators',
                reward: 'Generator output +50%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 0.5;
                }
            },
            {
                id: 'generators_200',
                name: 'Generator Complex',
                icon: '🏭',
                goal: 200,
                type: 'totalGenerators',
                reward: 'Generator output +100%',
                unlocked: false,
                apply: (game) => {
                    game.globalMultiplier += 1;
                }
            },
            {
                id: 'combo_75',
                name: 'Combo Champion',
                icon: '🔥',
                goal: 75,
                type: 'highestCombo',
                reward: 'Combo bonus +50%',
                unlocked: false,
                apply: (game) => {
                    game.comboBonus += 0.5;
                }
            },
            {
                id: 'combo_150',
                name: 'Combo Legend',
                icon: '✨',
                goal: 150,
                type: 'highestCombo',
                reward: 'Combo bonus +100%',
                unlocked: false,
                apply: (game) => {
                    game.comboBonus += 1;
                }
            }
        ];
    }

    check(game) {
        let newUnlocks = [];
        
        this.milestones.forEach(milestone => {
            if (!milestone.unlocked) {
                let current = 0;
                
                switch(milestone.type) {
                    case 'totalEnergy':
                        current = game.stats.totalEnergy;
                        break;
                    case 'totalClicks':
                        current = game.stats.totalClicks;
                        break;
                    case 'level':
                        current = game.level;
                        break;
                    case 'totalGenerators':
                        current = generatorsManager.generators.reduce((sum, g) => sum + g.count, 0);
                        break;
                    case 'highestCombo':
                        current = game.stats.highestCombo;
                        break;
                }
                
                if (current >= milestone.goal) {
                    milestone.unlocked = true;
                    milestone.apply(game);
                    newUnlocks.push(milestone);
                    
                    notifications.success(
                        '⭐ Milestone Reached!',
                        `${milestone.name} - ${milestone.reward}`,
                        4000
                    );
                    
                    // Create celebration
                    const milestoneCard = document.querySelector(`[data-milestone-id="${milestone.id}"]`);
                    if (milestoneCard) {
                        particleSystem.createCelebration(milestoneCard);
                    }
                }
            }
        });
        
        return newUnlocks;
    }

    getProgress(milestone, game) {
        let current = 0;
        
        switch(milestone.type) {
            case 'totalEnergy':
                current = game.stats.totalEnergy;
                break;
            case 'totalClicks':
                current = game.stats.totalClicks;
                break;
            case 'level':
                current = game.level;
                break;
            case 'totalGenerators':
                current = generatorsManager.generators.reduce((sum, g) => sum + g.count, 0);
                break;
            case 'highestCombo':
                current = game.stats.highestCombo;
                break;
        }
        
        return Math.min(100, (current / milestone.goal) * 100);
    }

    reset() {
        this.milestones.forEach(milestone => {
            milestone.unlocked = false;
        });
    }

    getSaveData() {
        const data = {};
        this.milestones.forEach(milestone => {
            data[milestone.id] = milestone.unlocked;
        });
        return data;
    }

    loadSaveData(data) {
        if (!data) return;
        Object.keys(data).forEach(id => {
            const milestone = this.milestones.find(m => m.id === id);
            if (milestone) {
                milestone.unlocked = data[id];
            }
        });
    }
}

const milestonesManager = new MilestonesManager();
